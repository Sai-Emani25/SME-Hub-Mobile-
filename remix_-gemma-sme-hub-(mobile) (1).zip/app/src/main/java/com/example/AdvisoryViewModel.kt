package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.encodeToString

class AdvisoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = FirestoreRepository(AppDatabase.getDatabase(application).dashboardDao())

    private val _uiState = MutableStateFlow<AdvisoryUiState>(AdvisoryUiState.Idle)
    val uiState: StateFlow<AdvisoryUiState> = _uiState.asStateFlow()

    private val _inventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val inventory = _inventory.asStateFlow()

    private val _sales = MutableStateFlow<List<SaleItem>>(emptyList())
    val sales = _sales.asStateFlow()

    private val _dataLoading = MutableStateFlow(false)
    val dataLoading = _dataLoading.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _dataLoading.value = true
            try {
                val inv = repository.getInventory()
                val s = repository.getSales()
                _inventory.value = inv
                _sales.value = s
            } catch (e: Exception) {
                // Handle error if needed
            } finally {
                _dataLoading.value = false
            }
        }
    }

    fun analyzeData(isDemo: Boolean = false) {
        _uiState.value = AdvisoryUiState.Loading
        viewModelScope.launch {
            try {
                val dataToAnalyze = if (isDemo) {
                    val inventoryJson = Json.encodeToString(DemoService.getDemoInventory())
                    val salesJson = Json.encodeToString(DemoService.getDemoSales())
                    "Demo Inventory: $inventoryJson\nDemo Sales: $salesJson"
                } else {
                    val inventoryJson = Json.encodeToString(_inventory.value)
                    val salesJson = Json.encodeToString(_sales.value)
                    "Inventory: $inventoryJson\nSales: $salesJson"
                }
                val result = withContext(Dispatchers.IO) {
                    performAnalysis(dataToAnalyze)
                }
                _uiState.value = AdvisoryUiState.Success(result)
            } catch (e: Exception) {
                _uiState.value = AdvisoryUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    private suspend fun performAnalysis(businessData: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return """{"error": "Gemini API key is missing. Please configure it in the AI Studio Secrets panel."}"""
        }

        val prompt = "Analyze the following business data:\n$businessData"

        val systemInstruction = """
            You are the Gemma SME Growth & Advisory Agent, a high-level strategic consultant for small and medium-sized enterprises. Your purpose is to ingest structured business data (from spreadsheets/CSV) and translate it into actionable financial strategies.

            CORE CAPABILITIES:
            1. Budget & Cost Analysis: Identify cash bleed, operational inefficiencies, and over-leveraged supplier contracts.
            2. Revenue Forecasting: Analyze sales patterns to predict cash flow and inventory needs.
            3. Pricing & Negotiation: Recommend pricing adjustments and supplier negotiation talking points based on margin data.
            4. Collections Strategy: Assess outstanding invoice data and draft context-aware collection communications.

            OPERATIONAL GUIDELINES:
            - You will receive business data representing inventory and sales.
            - Always perform a "Health Check" on the data provided: Flag anomalies, low margins, or high-risk suppliers.
            - When suggesting budget cuts, prioritize high-impact/low-effort actions.
            - Output MUST be strictly formatted as a JSON object without markdown fences.
            - Tone: Professional, analytical, proactive, and encouraging.
        """.trimIndent()

        val jsonSchema = buildJsonObject {
            put("type", "OBJECT")
            putJsonObject("properties") {
                putJsonObject("business_health_score") {
                    put("type", "INTEGER")
                    put("description", "0-100 score based on cash flow and margin")
                }
                putJsonObject("primary_insight") {
                    put("type", "STRING")
                }
                putJsonObject("budget_cuts_recommended") {
                    put("type", "ARRAY")
                    putJsonObject("items") {
                        put("type", "OBJECT")
                        putJsonObject("properties") {
                            putJsonObject("area") { put("type", "STRING") }
                            putJsonObject("saving_estimate") { put("type", "STRING") }
                            putJsonObject("action_plan") { put("type", "STRING") }
                        }
                    }
                }
                putJsonObject("negotiation_talking_points") {
                    put("type", "ARRAY")
                    putJsonObject("items") { put("type", "STRING") }
                }
                putJsonObject("risk_level") {
                    put("type", "STRING")
                    putJsonArray("enum") {
                        add(Json.parseToJsonElement("\"Low\""))
                        add(Json.parseToJsonElement("\"Medium\""))
                        add(Json.parseToJsonElement("\"High\""))
                        add(Json.parseToJsonElement("\"Critical\""))
                    }
                }
            }
            putJsonArray("required") {
                add(Json.parseToJsonElement("\"business_health_score\""))
                add(Json.parseToJsonElement("\"primary_insight\""))
                add(Json.parseToJsonElement("\"budget_cuts_recommended\""))
                add(Json.parseToJsonElement("\"risk_level\""))
            }
        }

        val toolsList = listOf(
            buildJsonObject {
                putJsonObject("googleSearch") {}
            }
        )

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = jsonSchema,
                temperature = 0.2f
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstruction))),
            tools = toolsList
        )

        return try {
            val response = RetrofitClient.service.generateContent("gemini-3.1-pro-preview", apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: """{"error": "Empty response"}"""
        } catch (e: Exception) {
             """{"error": "API Error: ${e.message}"}"""
        }
    }
}

sealed class AdvisoryUiState {
    object Idle : AdvisoryUiState()
    object Loading : AdvisoryUiState()
    data class Success(val result: String) : AdvisoryUiState()
    data class Error(val message: String) : AdvisoryUiState()
}
