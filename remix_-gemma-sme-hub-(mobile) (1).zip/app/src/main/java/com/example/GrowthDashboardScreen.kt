package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.core.content.FileProvider
import android.content.Context
import android.content.Intent
import java.io.File
import com.example.ui.theme.*
import org.json.JSONObject

@Composable
fun GrowthDashboardScreen(viewModel: AdvisoryViewModel, isDemo: Boolean = false, modifier: Modifier = Modifier) {
    val uiState by viewModel.uiState.collectAsState()
    val actualInventory by viewModel.inventory.collectAsState()
    val actualSales by viewModel.sales.collectAsState()
    val dataLoading by viewModel.dataLoading.collectAsState()

    val inventory = if (isDemo) DemoService.getDemoInventory() else actualInventory
    val sales = if (isDemo) DemoService.getDemoSales() else actualSales
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SME Growth Advisory",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextOnBg
            )
            
            IconButton(onClick = { exportDataToCsv(context, inventory, sales) }) {
                Icon(Icons.Default.Share, contentDescription = "Export Data", tint = PrimaryButton)
            }
        }
        
        if (dataLoading) {
            Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryButton)
            }
        } else {
            // Revenue Chart
            if (sales.isNotEmpty()) {
                RevenueBarChart(sales)
            }

            // Display Sales Summary
            Text("Recent Sales", fontWeight = FontWeight.SemiBold, color = TextOnBg)
            if (sales.isEmpty()) {
                Text("No sales data available.", color = TextSecondary, fontSize = 14.sp)
            } else {
                sales.take(3).forEach { sale ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                    ) {
                        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(sale.date, color = TextColor)
                            Text("$${sale.amount} (${sale.itemsSold} items)", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        }
                    }
                }
            }

            // Display Inventory Summary
            Text("Current Inventory", fontWeight = FontWeight.SemiBold, color = TextOnBg)
            if (inventory.isEmpty()) {
                Text("No inventory data available.", color = TextSecondary, fontSize = 14.sp)
            } else {
                inventory.take(3).forEach { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                    ) {
                        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.name, color = TextColor)
                            Text("Qty: ${item.quantity}", fontWeight = FontWeight.Bold, color = TextColor)
                        }
                    }
                }
            }
        }

        Button(
            onClick = { viewModel.analyzeData(isDemo) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton),
            shape = RoundedCornerShape(28.dp),
            enabled = uiState !is AdvisoryUiState.Loading && !dataLoading
        ) {
            if (uiState is AdvisoryUiState.Loading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
            } else {
                Text("Run Advisory Analysis", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }

        if (uiState is AdvisoryUiState.Error) {
             Text("Error: ${(uiState as AdvisoryUiState.Error).message}", color = MaterialTheme.colorScheme.error)
        }

        if (uiState is AdvisoryUiState.Success) {
             val jsonResult = (uiState as AdvisoryUiState.Success).result
             AnalysisDashboardView(jsonResult)
        } else if (uiState !is AdvisoryUiState.Loading && uiState !is AdvisoryUiState.Error) {
             Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
             ) {
                SummaryCard("Monthly Rev", "$42.5K", "+12% vs last month", true, Modifier.weight(1f))
                SummaryCard("Total Costs", "$28.1K", "-2% vs last month", true, Modifier.weight(1f))
             }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun AnalysisDashboardView(jsonString: String) {
    var healthScore by remember { mutableStateOf(0) }
    var riskLevel by remember { mutableStateOf("") }
    var insight by remember { mutableStateOf("") }
    var budgetCuts by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var talkingPoints by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(jsonString) {
        try {
            val obj = JSONObject(jsonString)
            if (obj.has("error")) {
                insight = obj.getString("error")
                return@LaunchedEffect
            }
            healthScore = obj.optInt("business_health_score", 0)
            riskLevel = obj.optString("risk_level", "Unknown")
            insight = obj.optString("primary_insight", "")
            
            val cutsArray = obj.optJSONArray("budget_cuts_recommended")
            val cutsList = mutableListOf<Map<String, String>>()
            if (cutsArray != null) {
                for (i in 0 until cutsArray.length()) {
                    val cutObj = cutsArray.getJSONObject(i)
                    cutsList.add(
                        mapOf(
                            "area" to cutObj.optString("area"),
                            "saving" to cutObj.optString("saving_estimate"),
                            "plan" to cutObj.optString("action_plan")
                        )
                    )
                }
            }
            budgetCuts = cutsList

            val tpArray = obj.optJSONArray("negotiation_talking_points")
            val tpList = mutableListOf<String>()
            if (tpArray != null) {
                for (i in 0 until tpArray.length()) {
                    tpList.add(tpArray.getString(i))
                }
            }
            talkingPoints = tpList
        } catch (e: Exception) {
            insight = "Failed to parse API response: $jsonString"
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SummaryCard("Health Score", "$healthScore/100", "Risk: $riskLevel", healthScore >= 70, Modifier.weight(1f))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PrimaryButton.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("💡", fontSize = 20.sp)
                Text("Primary Insight", fontWeight = FontWeight.Bold, color = TextOnBg)
            }
            Text(insight, color = TextOnBg, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }

    if (budgetCuts.isNotEmpty()) {
        Text("Recommended Budget Cuts", fontWeight = FontWeight.Bold, color = TextOnBg, modifier = Modifier.padding(top = 8.dp))
        budgetCuts.forEach { cut ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cut["area"] ?: "", fontWeight = FontWeight.Bold, color = TextColor)
                        Text(cut["saving"] ?: "", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(cut["plan"] ?: "", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }

    if (talkingPoints.isNotEmpty()) {
        Text("Negotiation Talking Points", fontWeight = FontWeight.Bold, color = TextOnBg, modifier = Modifier.padding(top = 8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                talkingPoints.forEach { pt ->
                    Row {
                        Text("• ", color = TextColor, fontWeight = FontWeight.Bold)
                        Text(pt, fontSize = 14.sp, color = TextColor, lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, trend: String, isPositive: Boolean, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = TextSecondary, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = TextColor)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                trend,
                color = if (isPositive) Color(0xFF16A34A) else Color(0xFFDC2626),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun RevenueBarChart(sales: List<SaleItem>) {
    if (sales.isEmpty()) return
    
    val data = sales.take(7).map { it.amount.toFloat() } // Limit to 7 items for chart
    
    // Linear Regression
    val n = data.size
    val sumX = (0 until n).sum().toFloat()
    val sumY = data.sum()
    val sumXX = (0 until n).sumOf { it * it }.toFloat()
    val sumXY = data.mapIndexed { index, y -> index * y }.sum()
    
    val m = if (n > 1) (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX) else 0f
    val b = if (n > 0) (sumY - m * sumX) / n else data.firstOrNull() ?: 0f
    
    // Predict next value
    val predictedData = data + (m * n + b).coerceAtLeast(0f)
    val maxVal = predictedData.maxOrNull() ?: 1f

    val extendedSales = sales.take(7).map { it.date.take(5) } + listOf("Proj")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Revenue Trends & Prediction", fontWeight = FontWeight.Bold, color = TextOnBg)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFFF59E0B), RoundedCornerShape(50)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Prediction", fontSize = 10.sp, color = TextSecondary)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            Box(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    predictedData.forEachIndexed { index, amount ->
                        val heightRatio = if (maxVal > 0) (amount / maxVal).coerceIn(0f, 1f) else 0f
                        val isPredicted = index == predictedData.size - 1
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier.weight(1f).fillMaxHeight()
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.6f)
                                        .fillMaxHeight(heightRatio)
                                        .background(
                                            if (isPredicted) PrimaryButton.copy(alpha = 0.3f) else PrimaryButton,
                                            RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                                        )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = extendedSales.getOrElse(index) { "-" },
                                fontSize = 10.sp,
                                color = if (isPredicted) Color(0xFFF59E0B) else TextSecondary,
                                maxLines = 1,
                                fontWeight = if (isPredicted) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
                
                Canvas(modifier = Modifier.fillMaxSize().padding(bottom = 22.dp)) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height
                    
                    val itemsCount = predictedData.size
                    val stepX = canvasWidth / itemsCount
                    
                    val path = Path()
                    var isFirst = true
                    
                    for (i in 0 until itemsCount) {
                        val predictedY = (m * i + b).coerceAtLeast(0f)
                        val normalizedY = if (maxVal > 0) (predictedY / maxVal).coerceIn(0f, 1f) else 0f
                        val x = stepX * i + (stepX / 2)
                        val y = canvasHeight - (normalizedY * canvasHeight)
                        
                        if (isFirst) {
                            path.moveTo(x, y)
                            isFirst = false
                        } else {
                            path.lineTo(x, y)
                        }
                        
                        drawCircle(
                            color = Color(0xFFF59E0B),
                            radius = 4.dp.toPx(),
                            center = Offset(x, y)
                        )
                    }
                    
                    drawPath(
                        path = path,
                        color = Color(0xFFF59E0B),
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    )
                }
            }
        }
    }
}

fun exportDataToCsv(context: Context, inventory: List<InventoryItem>, sales: List<SaleItem>) {
    try {
        val csvBuilder = java.lang.StringBuilder()
        csvBuilder.append("--- Inventory Data ---\n")
        csvBuilder.append("ID,Name,Quantity,Price\n")
        inventory.forEach {
            csvBuilder.append("${it.id},${it.name.replace(",", " ")},${it.quantity},${it.price}\n")
        }
        
        csvBuilder.append("\n--- Sales Data ---\n")
        csvBuilder.append("ID,Date,Amount,Items Sold\n")
        sales.forEach {
            csvBuilder.append("${it.id},${it.date},${it.amount},${it.itemsSold}\n")
        }
        
        val file = File(context.cacheDir, "business_data.csv")
        file.writeText(csvBuilder.toString())
        
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "Business Data Export")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export Business Data"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

