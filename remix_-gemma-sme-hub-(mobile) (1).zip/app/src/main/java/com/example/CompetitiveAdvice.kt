package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "competitive_advices")
data class CompetitiveAdvice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val adviceContent: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface CompetitiveAdviceDao {
    @Query("SELECT * FROM competitive_advices ORDER BY timestamp DESC")
    fun getAllAdvices(): Flow<List<CompetitiveAdvice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvice(advice: CompetitiveAdvice)

    @Query("DELETE FROM competitive_advices WHERE id = :id")
    suspend fun deleteAdviceById(id: Int)
}
