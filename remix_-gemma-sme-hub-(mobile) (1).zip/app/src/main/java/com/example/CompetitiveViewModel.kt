package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CompetitiveViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: AdviceRepository
    
    val savedAdvices: StateFlow<List<CompetitiveAdvice>>

    private val _currentAdvice = MutableStateFlow<String?>(null)
    val currentAdvice = _currentAdvice.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AdviceRepository(database.competitiveAdviceDao())
        
        savedAdvices = repository.allAdvices.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun analyzeCompetition(inventory: List<InventoryItem>, sales: List<SaleItem>) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            _currentAdvice.value = "Gemini API key is missing. Please configure it in the AI Studio Secrets panel."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val inventoryStr = inventory.joinToString { "${it.name}: ${it.quantity} at \$${it.price}" }
                val salesStr = sales.joinToString { "${it.date}: \$${it.amount} (${it.itemsSold} items)" }
                
                val promptText = "Analyze this inventory and sales data for competitive comparison, and give tips and tricks to improve the business. Keep it concise, actionable, and suitable for an SME.\nInventory: $inventoryStr\nSales: $salesStr"
                
                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = promptText)))),
                    systemInstruction = Content(parts = listOf(Part(text = "You are an expert business analyst.")))
                )
                
                val response = RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
                val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Could not generate advice."
                _currentAdvice.value = reply
            } catch (e: Exception) {
                _currentAdvice.value = "Error analyzing competition: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun saveCurrentAdvice(title: String) {
        val content = _currentAdvice.value ?: return
        viewModelScope.launch {
            repository.insert(CompetitiveAdvice(title = title, adviceContent = content))
        }
    }

    fun deleteAdvice(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }
}
