package com.example

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AuthViewModel : ViewModel() {
    private val auth = Firebase.auth
    val firestore = Firebase.firestore

    private val _currentUser = MutableStateFlow(auth.currentUser)
    val currentUser = _currentUser.asStateFlow()

    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode = _isDemoMode.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    
    private val _isConnecting = MutableStateFlow(false)
    val isConnecting = _isConnecting.asStateFlow()

    private val _ttsLanguage = MutableStateFlow("hi") // Hindi by default
    val ttsLanguage = _ttsLanguage.asStateFlow()

    fun setTtsLanguage(langCode: String) {
        _ttsLanguage.value = langCode
    }

    init {
        auth.addAuthStateListener { firebaseAuth ->
            _currentUser.value = firebaseAuth.currentUser
        }
    }

    fun signInWithGoogle(context: Context) {
        viewModelScope.launch {
            try {
                _isConnecting.value = true
                val credentialManager = CredentialManager.create(context)
                
                // Uses the key from Secrets plugin (via .env or .env.example)
                val clientId = BuildConfig.WEB_CLIENT_ID
                
                if (clientId.isBlank() || clientId == "YOUR_WEB_CLIENT_ID") {
                    _error.value = "Please configure WEB_CLIENT_ID in the Secrets panel."
                    _isConnecting.value = false
                    return@launch
                }

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(clientId)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(context, request)
                val credential = result.credential

                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                    
                    auth.signInWithCredential(authCredential).await()
                    _error.value = null
                } else {
                    _error.value = "Unexpected credential type."
                }
            } catch (e: Exception) {
                _error.value = "Sign in failed: ${e.message}"
            } finally {
                _isConnecting.value = false
            }
        }
    }

    fun signInAnonymously() {
        _isDemoMode.value = true
        _error.value = null
    }

    fun signOut() {
        _isDemoMode.value = false
        auth.signOut()
    }
    
    fun clearError() {
        _error.value = null
    }
}
