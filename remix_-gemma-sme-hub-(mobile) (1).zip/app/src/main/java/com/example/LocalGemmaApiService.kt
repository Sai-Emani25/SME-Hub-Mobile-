package com.example

import retrofit2.http.Body
import retrofit2.http.POST

// Technical Architecture Hook for Local Gemma
// Points to the standard Android Emulator loopback path for a local LM Studio server
data class ChatMessage(val role: String, val content: String)
data class ChatRequest(val model: String = "gemma-2-2b-it", val messages: List<ChatMessage>, val temperature: Float = 0.7f)
data class ChatResponse(val choices: List<Choice>)
data class Choice(val message: ChatMessage)

interface LocalGemmaApiService {
    @POST("v1/chat/completions")
    suspend fun streamChatCompletion(
        @Body request: ChatRequest
    ): ChatResponse
}
