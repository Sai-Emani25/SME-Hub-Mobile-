package com.example

object DemoService {
    val mockBusinessData: String = """[
  {"month": "Jan", "revenue": 45000, "expenses": 38000, "supplier_costs": 25000, "inventory": 85},
  {"month": "Feb", "revenue": 42000, "expenses": 39500, "supplier_costs": 26000, "inventory": 70},
  {"month": "Mar", "revenue": 41500, "expenses": 41000, "supplier_costs": 28000, "inventory": 55}
]"""

    fun getDemoData(): String {
        return mockBusinessData
    }

    fun getDemoInventory(): List<InventoryItem> = listOf(
        InventoryItem("1", "Raw Aluminum", 450, 2.40),
        InventoryItem("2", "Copper Wire", 120, 4.10),
        InventoryItem("3", "Packaging Cardboard", 850, 0.55),
        InventoryItem("4", "Lithium Carbonate", 40, 12.50)
    )

    fun getDemoSales(): List<SaleItem> = listOf(
        SaleItem("1", "2026-07-16", 4200.0, 150),
        SaleItem("2", "2026-07-17", 5100.0, 180),
        SaleItem("3", "2026-07-18", 3800.0, 120),
        SaleItem("4", "2026-07-19", 6400.0, 210),
        SaleItem("5", "2026-07-20", 4900.0, 165)
    )
}
