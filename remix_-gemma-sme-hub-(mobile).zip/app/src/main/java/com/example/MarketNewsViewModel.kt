package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import kotlinx.serialization.encodeToString

sealed class MarketUiState {
    object Idle : MarketUiState()
    object Loading : MarketUiState()
    data class Success(val result: String) : MarketUiState()
    data class Error(val message: String) : MarketUiState()
}

sealed class NewsUiState {
    object Idle : NewsUiState()
    object Loading : NewsUiState()
    data class Success(val result: String) : NewsUiState()
    data class Error(val message: String) : NewsUiState()
}

class MarketNewsViewModel : ViewModel() {
    private val _marketState = MutableStateFlow<MarketUiState>(MarketUiState.Idle)
    val marketState: StateFlow<MarketUiState> = _marketState.asStateFlow()

    private val _newsState = MutableStateFlow<NewsUiState>(NewsUiState.Idle)
    val newsState: StateFlow<NewsUiState> = _newsState.asStateFlow()

    fun fetchMarketRecommendations(businessData: String, isDemo: Boolean = false) {
        _marketState.value = MarketUiState.Loading
        viewModelScope.launch {
            try {
                val dataToAnalyze = if (isDemo) {
                    val invJson = Json.encodeToString(DemoService.getDemoInventory())
                    "Demo Inventory Data:\n$invJson"
                } else {
                    businessData
                }
                val result = withContext(Dispatchers.IO) { performMarketAnalysis(dataToAnalyze) }
                _marketState.value = MarketUiState.Success(result)
            } catch (e: Exception) {
                _marketState.value = MarketUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun fetchBusinessNews(businessData: String, isDemo: Boolean = false) {
        _newsState.value = NewsUiState.Loading
        viewModelScope.launch {
            try {
                val dataToAnalyze = if (isDemo) {
                    val invJson = Json.encodeToString(DemoService.getDemoInventory())
                    "Demo Inventory Data:\n$invJson"
                } else {
                    businessData
                }
                val result = withContext(Dispatchers.IO) { performNewsAnalysis(dataToAnalyze) }
                _newsState.value = NewsUiState.Success(result)
            } catch (e: Exception) {
                _newsState.value = NewsUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    private suspend fun performMarketAnalysis(businessData: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return """[{"material": "Error", "current_price": "-", "trend": "-", "recommendation": "-", "reasoning": "Gemini API key is missing. Please configure it in the AI Studio Secrets panel."}]"""
        }

        val prompt = "Based on this business data (from Google Drive Excel sheets):\n$businessData\nRecommend which raw materials to buy right now. Include real-time market simulation."
        val jsonSchema = buildJsonObject {
            put("type", "ARRAY")
            putJsonObject("items") {
                put("type", "OBJECT")
                putJsonObject("properties") {
                    putJsonObject("material") { put("type", "STRING") }
                    putJsonObject("current_price") { put("type", "STRING") }
                    putJsonObject("trend") { 
                        put("type", "STRING") 
                        putJsonArray("enum") { 
                            add(Json.parseToJsonElement("\"Up\""))
                            add(Json.parseToJsonElement("\"Down\""))
                            add(Json.parseToJsonElement("\"Stable\""))
                        }
                    }
                    putJsonObject("recommendation") { 
                        put("type", "STRING")
                        putJsonArray("enum") { 
                            add(Json.parseToJsonElement("\"Buy\""))
                            add(Json.parseToJsonElement("\"Hold\""))
                            add(Json.parseToJsonElement("\"Sell/Delay\""))
                            add(Json.parseToJsonElement("\"Stockpile\""))
                        }
                    }
                    putJsonObject("reasoning") { put("type", "STRING") }
                    putJsonObject("supply_chain_risk") { 
                        put("type", "STRING")
                        putJsonArray("enum") { 
                            add(Json.parseToJsonElement("\"Low\""))
                            add(Json.parseToJsonElement("\"Medium\""))
                            add(Json.parseToJsonElement("\"High\""))
                            add(Json.parseToJsonElement("\"Critical\""))
                        }
                    }
                    putJsonObject("local_demand_heat") { put("type", "STRING") }
                    putJsonObject("projected_price_change") { put("type", "STRING") }
                    putJsonObject("competitor_action") { put("type", "STRING") }
                }
                putJsonArray("required") {
                    add(Json.parseToJsonElement("\"material\""))
                    add(Json.parseToJsonElement("\"current_price\""))
                    add(Json.parseToJsonElement("\"trend\""))
                    add(Json.parseToJsonElement("\"recommendation\""))
                    add(Json.parseToJsonElement("\"reasoning\""))
                    add(Json.parseToJsonElement("\"supply_chain_risk\""))
                    add(Json.parseToJsonElement("\"local_demand_heat\""))
                    add(Json.parseToJsonElement("\"projected_price_change\""))
                    add(Json.parseToJsonElement("\"competitor_action\""))
                }
            }
        }

        val toolsList = listOf(
            buildJsonObject {
                putJsonObject("googleSearch") {}
            }
        )

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = jsonSchema,
                temperature = 0.4f
            ),
            systemInstruction = Content(parts = listOf(Part(text = "You are an AI Product Market Analyst. Tell the user which raw materials to buy, hold, or delay purchasing based on their business data and simulated real-time market changes. Use Google Search to get the latest real-time prices and news for these materials."))),
            tools = toolsList
        )
        val response = RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
        return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "[]"
    }

    private suspend fun performNewsAnalysis(businessData: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY" || apiKey.startsWith("AQ.Ab")) {
             return """[{"headline": "Configuration Error", "analysis": "Gemini API key is missing. Please configure it in the AI Studio Secrets panel."}]"""
        }

        val prompt = "Based on this business data:\n$businessData\nGenerate 3 relevant current business news headlines and provide a brief analysis report for each on how it impacts the business."
        val jsonSchema = buildJsonObject {
            put("type", "ARRAY")
            putJsonObject("items") {
                put("type", "OBJECT")
                putJsonObject("properties") {
                    putJsonObject("headline") { put("type", "STRING") }
                    putJsonObject("analysis") { put("type", "STRING") }
                }
                putJsonArray("required") {
                    add(Json.parseToJsonElement("\"headline\""))
                    add(Json.parseToJsonElement("\"analysis\""))
                }
            }
        }

        val toolsList = listOf(
            buildJsonObject {
                putJsonObject("googleSearch") {}
            }
        )

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = jsonSchema,
                temperature = 0.5f
            ),
            systemInstruction = Content(parts = listOf(Part(text = "You are an AI Business News Analyst. Provide relevant real-time news headlines based on the user's industry data and an analysis report of how it impacts their business. Use Google Search."))),
            tools = toolsList
        )
        val response = RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
        return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "[]"
    }
}
