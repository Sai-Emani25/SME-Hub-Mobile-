package com.example.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryButton,
    onPrimary = Color.White,
    primaryContainer = PrimaryLight,
    onPrimaryContainer = OnPrimaryLight,
    background = BgColor,
    onBackground = TextOnBg,
    surface = SurfaceColor,
    onSurface = TextColor,
    onSurfaceVariant = TextSecondary,
    errorContainer = ErrorBg,
    onErrorContainer = ErrorText,
    error = ErrorColor,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
