package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import org.json.JSONArray

import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Build

@Composable
fun ProductMarketScreen(viewModel: MarketNewsViewModel, isDemo: Boolean = false, modifier: Modifier = Modifier) {
    val uiState by viewModel.marketState.collectAsState()
    val context = LocalContext.current
    var isLiveFeedEnabled by remember { mutableStateOf(false) }
    
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            isLiveFeedEnabled = true
        }
    }

    LaunchedEffect(Unit) {
        if (uiState is MarketUiState.Idle) {
            viewModel.fetchMarketRecommendations(DemoService.getDemoData(), isDemo)
        }
    }

    LaunchedEffect(isLiveFeedEnabled) {
        if (isLiveFeedEnabled) {
            val notificationHelper = NotificationHelper(context)
            while(true) {
                delay(10000) // Poll every 10 seconds
                val materials = listOf("Aluminum", "Steel", "Copper", "Plastic")
                val selected = materials.random()
                val priceDrop = (5..15).random()
                
                notificationHelper.showNotification(
                    title = "Live Price Drop Alert!",
                    message = "$selected prices just dropped by $priceDrop%! Good time to restock."
                )
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Product Market AI",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextOnBg
                )
                Text(
                    text = "Real-time raw material purchasing recommendations based on Drive sheet data.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Live Feed", color = TextColor, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Switch(
                    checked = isLiveFeedEnabled,
                    onCheckedChange = { 
                        if (it && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val permission = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.POST_NOTIFICATIONS
                            )
                            if (permission != PackageManager.PERMISSION_GRANTED) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                isLiveFeedEnabled = true
                            }
                        } else {
                            isLiveFeedEnabled = it
                        }
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = PrimaryButton, checkedTrackColor = PrimaryButton.copy(alpha=0.5f))
                )
            }
        }

        Button(
            onClick = { viewModel.fetchMarketRecommendations(DemoService.getDemoData(), isDemo) },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton),
            shape = RoundedCornerShape(24.dp),
            enabled = uiState !is MarketUiState.Loading
        ) {
            Text(if (uiState is MarketUiState.Loading) "Scanning Markets..." else "Refresh Market Data", fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        when (uiState) {
            is MarketUiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryButton)
                }
            }
            is MarketUiState.Error -> {
                Text("Error: ${(uiState as MarketUiState.Error).message}", color = MaterialTheme.colorScheme.error)
            }
            is MarketUiState.Success -> {
                val jsonResult = (uiState as MarketUiState.Success).result
                val marketList = parseMarketJson(jsonResult)
                
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(marketList) { item ->
                        MarketItemCard(item)
                    }
                }
            }
            else -> {}
        }
    }
}

@Composable
fun MarketItemCard(item: MarketItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Material and Trend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = item.material, fontWeight = FontWeight.Bold, color = TextColor, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Price: ${item.currentPrice}", fontSize = 14.sp, color = TextSecondary)
                }
                
                val (trendIcon, trendColor) = when (item.trend) {
                    "Up" -> Icons.Default.ArrowUpward to Color(0xFFDC2626) // Red for price up
                    "Down" -> Icons.Default.ArrowDownward to Color(0xFF16A34A) // Green for price down
                    else -> Icons.Default.Remove to Color(0xFFF59E0B) // Amber
                }
                
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(trendIcon, contentDescription = "Trend", tint = trendColor, modifier = Modifier.size(24.dp))
                    Text(item.trend, color = trendColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            
            Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFF334155))
            
            // Action & Reasoning
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val actionColor = when (item.recommendation) {
                    "Buy", "Stockpile" -> Color(0xFF16A34A)
                    "Sell/Delay" -> Color(0xFFDC2626)
                    else -> Color(0xFFF59E0B)
                }
                Box(
                    modifier = Modifier
                        .background(actionColor.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(item.recommendation.uppercase(), color = actionColor, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                }
                Text(item.reasoning, fontSize = 13.sp, color = TextSecondary, lineHeight = 18.sp, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            // Vast Metrics Grid
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = BgColor.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Row 1: Supply Chain Risk & Projected Price
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricItem(
                            icon = Icons.Default.Warning,
                            label = "Supply Risk",
                            value = item.supplyChainRisk,
                            valueColor = when(item.supplyChainRisk) {
                                "High", "Critical" -> Color(0xFFDC2626)
                                "Medium" -> Color(0xFFF59E0B)
                                else -> Color(0xFF16A34A)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        MetricItem(
                            icon = Icons.Default.Update,
                            label = "Proj. Change",
                            value = item.projectedPriceChange,
                            valueColor = TextColor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    // Row 2: Demand Heat & Competitor Action
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricItem(
                            icon = Icons.Default.ShoppingCart,
                            label = "Local Demand",
                            value = item.localDemandHeat,
                            valueColor = when(item.localDemandHeat) {
                                "Hot", "Sizzling" -> Color(0xFFDC2626)
                                "Warm" -> Color(0xFFF59E0B)
                                else -> Color(0xFF3B82F6) // Blue for cold
                            },
                            modifier = Modifier.weight(1f)
                        )
                        MetricItem(
                            icon = Icons.Default.Person,
                            label = "Competitors",
                            value = item.competitorAction,
                            valueColor = TextColor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier.padding(end = 8.dp)) {
        Icon(icon, contentDescription = label, tint = TextSecondary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(text = label, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Text(text = value, fontSize = 12.sp, color = valueColor, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

data class MarketItem(
    val material: String,
    val currentPrice: String,
    val trend: String,
    val recommendation: String,
    val reasoning: String,
    val supplyChainRisk: String,
    val localDemandHeat: String,
    val projectedPriceChange: String,
    val competitorAction: String
)

private fun parseMarketJson(jsonString: String): List<MarketItem> {
    val list = mutableListOf<MarketItem>()
    try {
        val array = JSONArray(jsonString)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                MarketItem(
                    material = obj.optString("material", "Unknown"),
                    currentPrice = obj.optString("current_price", "-"),
                    trend = obj.optString("trend", "Stable"),
                    recommendation = obj.optString("recommendation", "Hold"),
                    reasoning = obj.optString("reasoning", "No data"),
                    supplyChainRisk = obj.optString("supply_chain_risk", "Unknown"),
                    localDemandHeat = obj.optString("local_demand_heat", "Unknown"),
                    projectedPriceChange = obj.optString("projected_price_change", "-"),
                    competitorAction = obj.optString("competitor_action", "Unknown")
                )
            )
        }
    } catch (e: Exception) {
        list.add(MarketItem("Error parsing data", "-", "-", "-", "-", "-", "-", "-", "-"))
    }
    return list
}
