package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgColor = Color(0xFF0F172A)
val SurfaceColor = Color(0xFF1E293B)
val PrimaryButton = Color(0xFF3B82F6)
val PrimaryLight = Color(0xFF1D4ED8)
val OnPrimaryLight = Color(0xFFEFF6FF)

val TextColor = Color(0xFFF8FAFC)
val TextOnBg = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

val NavBg = Color(0xFF0F172A)

val SuccessColor = Color(0xFF10B981)
val WarningColor = Color(0xFFF59E0B)
val ErrorColor = Color(0xFFEF4444)

val ErrorBg = Color(0xFF450A0A)
val ErrorBorder = Color(0xFF7F1D1D)
val ErrorTagBg = Color(0xFF991B1B)
val ErrorText = Color(0xFFFEF2F2)
val ErrorTextSub = Color(0xFFFECACA)
