package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

import androidx.compose.material.icons.filled.PlayArrow
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun AdvisorChatScreen(viewModel: AccountantChatViewModel, authViewModel: AuthViewModel, modifier: Modifier = Modifier) {
    var inputText by remember { mutableStateOf("") }
    val messages by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val ttsLanguage by authViewModel.ttsLanguage.collectAsState()

    Column(modifier = modifier.fillMaxSize().background(BgColor).padding(16.dp)) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(msg, ttsLanguage)
            }
            if (isLoading) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.CenterStart) {
                        CircularProgressIndicator(color = PrimaryButton, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask your advisor...", color = TextSecondary) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = SurfaceColor,
                    focusedContainerColor = SurfaceColor,
                    unfocusedTextColor = TextColor,
                    focusedTextColor = TextColor,
                    focusedBorderColor = PrimaryButton,
                    unfocusedBorderColor = Color.Transparent
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isLoading) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .background(PrimaryButton, shape = RoundedCornerShape(50))
                    .size(48.dp),
                enabled = !isLoading
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun ChatBubble(msg: AdvisorChatMessage, ttsLanguage: String) {
    val alignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
    val bgColor = if (msg.isUser) PrimaryButton else SurfaceColor
    val textColor = if (msg.isUser) Color.White else TextColor
    val shape = if (msg.isUser) RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    else RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
    val ttsManager = LocalTtsManager.current

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Column(horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start) {
            Box(
                modifier = Modifier
                    .background(bgColor, shape)
                    .padding(16.dp)
            ) {
                Text(msg.text, color = textColor, fontSize = 14.sp)
            }
            if (!msg.isUser) {
                Row(
                    verticalAlignment = Alignment.CenterVertically, 
                    modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                ) {
                    Text("AI Chartered Accountant", fontSize = 10.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            ttsManager?.setLanguage(ttsLanguage)
                            ttsManager?.speak(msg.text)
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Listen", tint = PrimaryButton, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

