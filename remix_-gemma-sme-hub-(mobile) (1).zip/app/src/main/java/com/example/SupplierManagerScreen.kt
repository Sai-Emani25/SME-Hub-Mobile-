package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SupplierManagerScreen(modifier: Modifier = Modifier) {
    val competitiveViewModel: CompetitiveViewModel = viewModel()
    val isLoading by competitiveViewModel.isLoading.collectAsState()
    val currentAdvice by competitiveViewModel.currentAdvice.collectAsState()
    val savedAdvices by competitiveViewModel.savedAdvices.collectAsState()
    val ttsManager = LocalTtsManager.current
    val authViewModel: AuthViewModel = viewModel()
    val ttsLanguage by authViewModel.ttsLanguage.collectAsState()
    
    // Using Demo data for analysis
    val inventory = DemoService.getDemoInventory()
    val sales = DemoService.getDemoSales()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
    ) {
        Text(
            text = "Competitive Comparison",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextOnBg
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { competitiveViewModel.analyzeCompetition(inventory, sales) },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Text("✨ Generate Competitive Analysis & Tips", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (currentAdvice != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Current Analysis", fontWeight = FontWeight.Bold, color = TextColor)
                        Row {
                            IconButton(onClick = {
                                ttsManager?.setLanguage(ttsLanguage)
                                ttsManager?.speak(currentAdvice ?: "")
                            }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Listen", tint = PrimaryButton)
                            }
                            IconButton(onClick = {
                                competitiveViewModel.saveCurrentAdvice("Analysis - ${SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())}")
                            }) {
                                Icon(Icons.Default.Save, contentDescription = "Save Advice", tint = PrimaryButton)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = currentAdvice!!,
                        fontSize = 14.sp,
                        color = TextColor,
                        modifier = Modifier.verticalScroll(rememberScrollState()).heightIn(max = 200.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Text("Saved Advices", fontWeight = FontWeight.Bold, color = TextOnBg, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(savedAdvices) { advice ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(advice.title, fontWeight = FontWeight.Bold, color = TextColor)
                            Row {
                                IconButton(onClick = {
                                    ttsManager?.setLanguage(ttsLanguage)
                                    ttsManager?.speak(advice.adviceContent)
                                }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Listen", tint = PrimaryButton)
                                }
                                IconButton(onClick = { competitiveViewModel.deleteAdvice(advice.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                }
                            }
                        }
                        Text(advice.adviceContent, fontSize = 14.sp, color = TextSecondary, maxLines = 3)
                    }
                }
            }
        }
    }
}
