#!/bin/bash
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/CardWhite/SurfaceColor/g' {} +
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/Color\.Black/TextColor/g' {} +
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/Color\.DarkGray/TextSecondary/g' {} +
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/Color\.Gray/TextSecondary/g' {} +
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/Color(0xFF333333)/SurfaceColor/g' {} +
find app/src/main/java/com/example -type f -name "*.kt" -exec sed -i 's/Color(0xFF444444)/SurfaceColor/g' {} +
