package com.example

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.Serializable
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withTimeout

@Serializable
@Entity(tableName = "inventory_items")
data class InventoryItem(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val quantity: Int = 0,
    val price: Double = 0.0
)

@Serializable
@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey val id: String = "",
    val date: String = "",
    val amount: Double = 0.0,
    val itemsSold: Int = 0
)

@Dao
interface DashboardDao {
    @Query("SELECT * FROM inventory_items")
    suspend fun getInventory(): List<InventoryItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(items: List<InventoryItem>)

    @Query("SELECT * FROM sale_items")
    suspend fun getSales(): List<SaleItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSales(items: List<SaleItem>)
}

class FirestoreRepository(private val dao: DashboardDao) {
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun getInventory(): List<InventoryItem> {
        return try {
            val remoteItems = withTimeout(3000L) {
                val snapshot = firestore.collection("inventory").get().await()
                snapshot.documents.mapNotNull { doc ->
                    val item = doc.toObject(InventoryItem::class.java)
                    item?.copy(id = doc.id)
                }
            }
            if (remoteItems.isNotEmpty()) {
                dao.insertInventory(remoteItems)
            }
            remoteItems
        } catch (e: Exception) {
            dao.getInventory()
        }
    }

    suspend fun getSales(): List<SaleItem> {
        return try {
            val remoteItems = withTimeout(3000L) {
                val snapshot = firestore.collection("sales").get().await()
                snapshot.documents.mapNotNull { doc ->
                    val item = doc.toObject(SaleItem::class.java)
                    item?.copy(id = doc.id)
                }
            }
            if (remoteItems.isNotEmpty()) {
                dao.insertSales(remoteItems)
            }
            remoteItems
        } catch (e: Exception) {
            dao.getSales()
        }
    }
}
