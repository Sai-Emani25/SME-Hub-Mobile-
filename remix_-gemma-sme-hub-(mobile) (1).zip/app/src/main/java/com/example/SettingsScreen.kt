package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun SettingsScreen(authViewModel: AuthViewModel, modifier: Modifier = Modifier) {
    var posEnabled by remember { mutableStateOf(true) }
    var qbEnabled by remember { mutableStateOf(false) }
    var apiEnabled by remember { mutableStateOf(true) }
    
    var networkHost by remember { mutableStateOf("http://10.0.2.2:1234/v1") }
    var showDriveDialog by remember { mutableStateOf(false) }
    var connectedSheetName by remember { mutableStateOf<String?>(null) }
    
    val currentUser by authViewModel.currentUser.collectAsState()

    LaunchedEffect(currentUser) {
        currentUser?.let { user ->
            authViewModel.firestore.collection("Users").document(user.uid)
                .collection("DataSources").document("primary_sheet")
                .get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        connectedSheetName = doc.getString("file_name")
                    }
                }
        }
    }

    if (showDriveDialog) {
        var fileId by remember { mutableStateOf("") }
        var fileName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDriveDialog = false },
            title = { Text("Connect Google Sheet", color = TextColor) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter the unique ID and a name for the Google Sheet to act as your data source.", color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = fileId,
                        onValueChange = { fileId = it },
                        label = { Text("Sheet File ID") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextColor, unfocusedTextColor = TextColor)
                    )
                    OutlinedTextField(
                        value = fileName,
                        onValueChange = { fileName = it },
                        label = { Text("Sheet Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextColor, unfocusedTextColor = TextColor)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        currentUser?.let { user ->
                            val data = hashMapOf(
                                "file_id" to fileId,
                                "file_name" to fileName,
                                "connected_at" to System.currentTimeMillis()
                            )
                            authViewModel.firestore.collection("Users").document(user.uid)
                                .collection("DataSources").document("primary_sheet")
                                .set(data)
                                .addOnSuccessListener {
                                    connectedSheetName = fileName
                                    showDriveDialog = false
                                }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton)
                ) {
                    Text("Connect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDriveDialog = false }) { Text("Cancel", color = TextSecondary) }
            },
            containerColor = SurfaceColor
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Settings & Data Sources",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextOnBg
            )
            Button(
                onClick = { authViewModel.signOut() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Google Drive integration", fontWeight = FontWeight.Bold, color = TextColor, fontSize = 16.sp)
                Text("Store spreadsheets securely using a Pointer Registry in Firestore.", fontSize = 12.sp, color = TextSecondary)
                
                if (connectedSheetName != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.size(8.dp).background(Color(0xFF16A34A), CircleShape))
                        Text("Connected to: $connectedSheetName", color = TextColor, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    }
                }
                
                Button(
                    onClick = { showDriveDialog = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton)
                ) {
                    Text(if (connectedSheetName == null) "Connect Drive (Sheet)" else "Change Connected Sheet", fontWeight = FontWeight.Bold)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Data Connectors", fontWeight = FontWeight.Bold, color = TextColor, fontSize = 16.sp)
                
                ConnectorToggle("POS System", "Real-time sales sync", posEnabled) { posEnabled = it }
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                ConnectorToggle("Quickbooks", "Accounting software integration", qbEnabled) { qbEnabled = it }
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                ConnectorToggle("Supplier APIs", "Live inventory data", apiEnabled) { apiEnabled = it }
            }
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Voice Narration (TTS)", fontWeight = FontWeight.Bold, color = TextColor, fontSize = 16.sp)
                Text("Select the preferred language for AI voice narration.", fontSize = 12.sp, color = TextSecondary)
                
                val currentLangCode by authViewModel.ttsLanguage.collectAsState()
                
                val languages = listOf(
                    "hi" to "Hindi",
                    "bn" to "Bengali",
                    "te" to "Telugu",
                    "mr" to "Marathi",
                    "ta" to "Tamil",
                    "ur" to "Urdu",
                    "gu" to "Gujarati"
                )
                
                var expanded by remember { mutableStateOf(false) }
                
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextColor)
                    ) {
                        Text(languages.find { it.first == currentLangCode }?.second ?: "Hindi")
                    }
                    
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(SurfaceColor)
                    ) {
                        languages.forEach { (code, name) ->
                            DropdownMenuItem(
                                text = { Text(name, color = TextColor) },
                                onClick = {
                                    authViewModel.setTtsLanguage(code)
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Local LLM Configuration", fontWeight = FontWeight.Bold, color = TextColor, fontSize = 16.sp)
                Text("Connect to your local LM Studio instance for privacy-preserving AI inference.", fontSize = 12.sp, color = TextSecondary)
                
                OutlinedTextField(
                    value = networkHost,
                    onValueChange = { networkHost = it },
                    label = { Text("LLM Host Address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedTextColor = TextColor,
                        focusedTextColor = TextColor,
                        focusedBorderColor = PrimaryButton,
                    )
                )
                
                Button(
                    onClick = { /* Test Connection */ },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton)
                ) {
                    Text("Test Connection", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ConnectorToggle(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextColor)
            Text(subtitle, fontSize = 12.sp, color = TextSecondary)
        }
        Switch(
            checked = checked, 
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = PrimaryButton
            )
        )
    }
}
