package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import org.json.JSONArray

@Composable
fun BusinessNewsScreen(viewModel: MarketNewsViewModel, isDemo: Boolean = false, modifier: Modifier = Modifier) {
    val uiState by viewModel.newsState.collectAsState()
    
    LaunchedEffect(Unit) {
        if (uiState is NewsUiState.Idle) {
            viewModel.fetchBusinessNews(DemoService.getDemoData(), isDemo)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
    ) {
        Text(
            text = "Business News",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextOnBg
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        when (uiState) {
            is NewsUiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryButton)
                }
            }
            is NewsUiState.Error -> {
                Text("Error: ${(uiState as NewsUiState.Error).message}", color = MaterialTheme.colorScheme.error)
            }
            is NewsUiState.Success -> {
                val jsonResult = (uiState as NewsUiState.Success).result
                val newsList = parseNewsJson(jsonResult)
                
                LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(newsList) { news ->
                        NewsCard(headline = news.headline, analysis = news.analysis)
                    }
                }
            }
            else -> {}
        }
    }
}

@Composable
fun NewsCard(headline: String, analysis: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = headline,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextColor
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🤖", fontSize = 16.sp)
                Column {
                    Text("AI Analysis Report", fontSize = 12.sp, color = PrimaryButton, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = analysis,
                        fontSize = 14.sp,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

private data class NewsItem(val headline: String, val analysis: String)

private fun parseNewsJson(jsonString: String): List<NewsItem> {
    val list = mutableListOf<NewsItem>()
    try {
        val array = JSONArray(jsonString)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                NewsItem(
                    headline = obj.optString("headline"),
                    analysis = obj.optString("analysis")
                )
            )
        }
    } catch (e: Exception) {
        list.add(NewsItem("Failed to load news", "Could not parse JSON response."))
    }
    return list
}
