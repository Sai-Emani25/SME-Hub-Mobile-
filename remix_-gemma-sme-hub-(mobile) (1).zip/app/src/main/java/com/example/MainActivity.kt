package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavHostController
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.FirebaseApp

val LocalTtsManager = staticCompositionLocalOf<TTSManager?> { null }

class MainActivity : ComponentActivity() {
    private val advisoryViewModel: AdvisoryViewModel by viewModels()
    private val marketNewsViewModel: MarketNewsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        enableEdgeToEdge()
        setContent {
            val ttsManager = remember { TTSManager(this@MainActivity) }
            DisposableEffect(Unit) {
                onDispose { ttsManager.shutdown() }
            }
            CompositionLocalProvider(LocalTtsManager provides ttsManager) {
                MyApplicationTheme {
                val authViewModel: AuthViewModel = viewModel()
                val currentUser by authViewModel.currentUser.collectAsState()
                val isDemoMode by authViewModel.isDemoMode.collectAsState()

                if (currentUser == null && !isDemoMode) {
                    LoginScreen(authViewModel)
                } else {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route ?: "dashboard"

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = BgColor,
                        topBar = { AppTopBar() },
                        bottomBar = { AppBottomNav(currentRoute, navController) }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "dashboard",
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable("dashboard") { GrowthDashboardScreen(advisoryViewModel, isDemoMode) }
                            composable("market") { ProductMarketScreen(marketNewsViewModel, isDemoMode) }
                            composable("news") { BusinessNewsScreen(marketNewsViewModel, isDemoMode) }
                            composable("supplier") { SupplierManagerScreen() }
                            composable("chat") { 
                                val accountantChatViewModel: AccountantChatViewModel = viewModel()
                                AdvisorChatScreen(accountantChatViewModel, authViewModel) 
                            }
                            composable("settings") { SettingsScreen(authViewModel) }
                        }
                    }
                }
            }
            }
        }
    }
}

@Composable
fun AppTopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BgColor)
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(PrimaryButton.copy(alpha = 0.2f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("📈", fontSize = 20.sp)
            }
            Column {
                Text("Gemma SME Hub", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = TextOnBg, letterSpacing = (-0.5).sp)
                Text("LOCAL AI SECURED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8), letterSpacing = 1.sp)
            }
        }
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(Color.Transparent, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("⚙️", fontSize = 24.sp)
        }
    }
}

@Composable
fun AppBottomNav(currentRoute: String, navController: NavHostController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .height(72.dp)
            .background(NavBg)
            .drawBehind { 
                 drawLine(SurfaceColor, start = Offset(0f, 0f), end = Offset(size.width, 0f), strokeWidth = 1f)
            }
            .padding(horizontal = 4.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(modifier = Modifier.width(4.dp))
        NavItem("📈", "Growth", currentRoute == "dashboard") { navController.navigate("dashboard") { launchSingleTop = true } }
        NavItem("🛒", "Market", currentRoute == "market") { navController.navigate("market") { launchSingleTop = true } }
        NavItem("📰", "News", currentRoute == "news") { navController.navigate("news") { launchSingleTop = true } }
        NavItem("📦", "Supplier", currentRoute == "supplier") { navController.navigate("supplier") { launchSingleTop = true } }
        NavItem("💬", "Advisor", currentRoute == "chat") { navController.navigate("chat") { launchSingleTop = true } }
        NavItem("⚙️", "Settings", currentRoute == "settings") { navController.navigate("settings") { launchSingleTop = true } }
        Spacer(modifier = Modifier.width(4.dp))
    }
}

@Composable
fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = Color.Transparent,
        onClick = onClick,
        modifier = Modifier.padding(4.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.alpha(if (selected) 1f else 0.5f)
        ) {
            if (selected) {
                Box(
                    modifier = Modifier
                        .background(PrimaryButton, shape = CircleShape)
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(icon, fontSize = 18.sp)
                }
            } else {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(icon, fontSize = 18.sp)
                }
            }
            Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = TextOnBg)
        }
    }
}
