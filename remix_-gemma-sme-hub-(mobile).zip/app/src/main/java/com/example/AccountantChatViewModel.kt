package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AdvisorChatMessage(val text: String, val isUser: Boolean)

class AccountantChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<AdvisorChatMessage>>(emptyList())
    val messages: StateFlow<List<AdvisorChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        // Initial setup for the chartered accountant
        val initialPrompt = """
            You are a chartered accountant AI Advisor. Before the user asks anything, you must proactively provide 3 specific financial advices based on the user's business context:
            1. Money reallocation
            2. Competitive analysis
            3. Tax reduction strategies
            Provide this advice immediately in a friendly, professional tone. Keep it concise.
        """.trimIndent()
        
        sendMessage(initialPrompt, isSystemInit = true)
    }

    fun sendMessage(text: String, isSystemInit: Boolean = false) {
        if (!isSystemInit) {
            _messages.value = _messages.value + AdvisorChatMessage(text, true)
        }
        
        _isLoading.value = true
        
        viewModelScope.launch {
            try {
                // We format the conversation history for Gemini
                val contents = mutableListOf<Content>()
                _messages.value.forEach { msg ->
                    val role = if (msg.isUser) "user" else "model"
                    contents.add(Content(role = role, parts = listOf(Part(text = msg.text))))
                }
                if (isSystemInit) {
                    contents.add(Content(role = "user", parts = listOf(Part(text = text))))
                }
                
                val request = GenerateContentRequest(
                    contents = contents,
                    systemInstruction = Content(parts = listOf(Part(text = "You are an AI Chartered Accountant Advisor for a small-to-medium enterprise. Provide expert financial optimization advice, including money reallocation, tax reduction, and competitive analysis.")))
                )
                
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY" || apiKey.startsWith("AQ.Ab")) {
                    _messages.value = _messages.value + AdvisorChatMessage("Gemini API key is missing. Please configure it in the AI Studio Secrets panel.", false)
                    _isLoading.value = false
                    return@launch
                }
                val response = RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
                val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I am currently unable to process your request."
                
                _messages.value = _messages.value + AdvisorChatMessage(reply, false)
            } catch (e: Exception) {
                _messages.value = _messages.value + AdvisorChatMessage("Error connecting to Advisor: ${e.message}", false)
            } finally {
                _isLoading.value = false
            }
        }
    }
}
