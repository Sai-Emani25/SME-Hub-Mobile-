package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun SupplierManagerScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgColor)
            .padding(16.dp)
    ) {
        Text(
            text = "Supplier & Inventory",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextOnBg
        )
        
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { /* Run Restock Analysis */ },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryButton)
        ) {
            Text("✨ Run Restock Analysis", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SupplierCard("Global Tech Supplies", "Electronics", "Green")
            }
            item {
                SupplierCard("Apex Materials Co.", "Raw Aluminum", "Yellow")
            }
            item {
                SupplierCard("Logistics Network Inc.", "Shipping", "Red")
            }
        }
    }
}

@Composable
fun SupplierCard(name: String, category: String, status: String) {
    val statusColor = when (status) {
        "Green" -> Color(0xFF16A34A)
        "Yellow" -> Color(0xFFF59E0B)
        "Red" -> Color(0xFFDC2626)
        else -> TextSecondary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(name, fontWeight = FontWeight.Bold, color = TextColor)
                Text(category, fontSize = 12.sp, color = TextSecondary)
            }
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(statusColor, shape = CircleShape)
            )
        }
    }
}
