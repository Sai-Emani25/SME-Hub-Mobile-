package com.example

import kotlinx.coroutines.flow.Flow

class AdviceRepository(private val dao: CompetitiveAdviceDao) {
    val allAdvices: Flow<List<CompetitiveAdvice>> = dao.getAllAdvices()

    suspend fun insert(advice: CompetitiveAdvice) {
        dao.insertAdvice(advice)
    }

    suspend fun deleteById(id: Int) {
        dao.deleteAdviceById(id)
    }
}
