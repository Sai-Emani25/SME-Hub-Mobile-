# Project: SME-Advisor

## Overview
SME-Advisor is a cross-platform application (Android/Web) designed to provide data-driven insights and AI-powered management tools for Small and Medium Enterprises. The project uses a shared codebase for core business logic, with platform-specific initialization for Firebase and UI rendering.

## Architecture
- **Language:** Kotlin (Shared Logic)
- **Framework:** Compose Multiplatform
- **Backend/Services:** Firebase (Auth, Firestore)
- **AI Integration:** Google Gemini API

## Setup Instructions

### 1. Environment Configuration
To prevent credential leaks, this repository uses environment placeholders. Create a `.env` file in the root directory (do not commit this to version control):

```text
# Required for Gemini AI API calls
GEMINI_API_KEY=<YOUR_GEMINI_API_KEY_HERE>

# Required for Firebase Auth/Firestore
WEB_CLIENT_ID=<YOUR_WEB_CLIENT_ID_HERE>
```
