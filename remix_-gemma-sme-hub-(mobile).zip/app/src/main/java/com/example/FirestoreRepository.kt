package com.example

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class InventoryItem(
    val id: String = "",
    val name: String = "",
    val quantity: Int = 0,
    val price: Double = 0.0
)

data class SaleItem(
    val id: String = "",
    val date: String = "",
    val amount: Double = 0.0,
    val itemsSold: Int = 0
)

class FirestoreRepository {
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun getInventory(): List<InventoryItem> {
        return try {
            val snapshot = firestore.collection("inventory").get().await()
            snapshot.documents.mapNotNull { doc ->
                val item = doc.toObject(InventoryItem::class.java)
                item?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getSales(): List<SaleItem> {
        return try {
            val snapshot = firestore.collection("sales").get().await()
            snapshot.documents.mapNotNull { doc ->
                val item = doc.toObject(SaleItem::class.java)
                item?.copy(id = doc.id)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
